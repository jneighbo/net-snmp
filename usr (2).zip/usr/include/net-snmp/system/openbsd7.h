/* openbsd7 is a superset of all since openbsd3 */
#include "openbsd6.h"
#define openbsd6 openbsd6
